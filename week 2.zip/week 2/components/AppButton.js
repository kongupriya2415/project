//import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { StyleSheet, Text, SafeAreaView,Platform,StatusBar, View,Button} from 'react-native';
import color from '../app/color/config'
//import WelcomeScreen from './screens/WelcomeScreen';

const AppButton = () =>{
  return (
   <View style={styles.container}>
     
  <Text style = {styles.text}>
               LOGIN
            </Text>
            <Text style = {styles.textt}>
               REGISTER
            </Text>
       </View>
    
  );
}





export default AppButton;


const styles = StyleSheet.create({
    container:{
     flex:1,
     justifyContent:'flex-end',
     paddingRight: 27,
     marginBottom:20,
     
    },
   
    text: {
      borderWidth: 0.1,
      paddingLeft: 150,
      paddingTop: 10,
      borderColor: 'black',
      backgroundColor: color.primary,
      width:350,
      height:50,
      marginBottom:20,
      fontSize:20,
      borderRadius:100,
      color:'white'
   },
   textt: {
    borderWidth: 0.1,
    paddingLeft: 140,
    paddingTop: 10,
    borderColor: 'black',
    backgroundColor: color.secondary,
    width:350,
    height:50,
    marginBottom:20,
    fontSize:20,
    borderRadius:100,
    color:'white'
 }
    
 
});
