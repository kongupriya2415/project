import React from 'react'
import {ImageBackground,StyleSheet,SafeAreaView, View,Image,Text,Platform, Button} from 'react-native'
import AppButton from '../components/AppButton'

const WelcomeScreen = () =>{
return(
    
<View>
<ImageBackground style={styles.container} source= {require('../assets/background.jpg')} blurRadius={2}>
  
<Image style={styles.image} resizeMode='contain' source= {require('../assets/logo-red.png')}></Image>
<View style={{marginTop:15,marginRight:25}}>
<Text style={{fontSize:30}}>Sell What You Don't Need</Text> 
</View>

{/* <View style={{height:65,width:500,backgroundColor:"#fc5c65",marginTop:400,alignItems:'center'}} >

</View>
<View style={{height:65,width:500,backgroundColor:"#4ECDC4"}}></View> */}
<AppButton />


</ImageBackground>




</View>
)
}


export default WelcomeScreen;

const styles = StyleSheet.create({
    container:{
        height:"103%",
        width:"109%",
        alignItems:"center",
        padding: Platform.OS==='android'?25:0
    },
    image:{
        height:110,
        width:100,
        marginTop:30,
        marginRight:20,
        
    },
  
    
 
});
