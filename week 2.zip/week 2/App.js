//import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { StyleSheet, Text, SafeAreaView,Platform,StatusBar, View,Button} from 'react-native';
import WelcomeScreen from './screens/WelcomeScreen';
//import WelcomeScreen from './screens/WelcomeScreen';

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
{/*      
  <Text style = {styles.text}>
               LOGIN
            </Text>
             */}
      <WelcomeScreen />
      
    </SafeAreaView>
  );
}








const styles = StyleSheet.create({
    container:{
      flex:1,
      backgroundColor:"black",
       
     
      
     // padding: Platform.OS==='android'?StatusBar.currentHeight : 0
     //padding: Platform.OS==='android'?100:0
    },
    text: {
      borderWidth: 0.1,
      paddingLeft: 165,
      paddingTop: 10,
      borderColor: 'black',
      backgroundColor: '#fc5c65',
      width:390,
      height:50,
      marginBottom:20,
      fontSize:20,
      borderRadius:100,
      color:'white'
   },
   textt: {
    borderWidth: 0.1,
    paddingLeft: 150,
    paddingTop: 10,
    borderColor: 'black',
    backgroundColor: '#4ECDC4',
    width:390,
    height:50,
    marginBottom:20,
    fontSize:20,
    borderRadius:100
    
 }
    
 
});
